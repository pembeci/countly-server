var exportedPlugin = {};

(function(plugin) {
    plugin.init = function() {

    };
}(exportedPlugin));

module.exports = exportedPlugin;